const KEY = "focusforge-v1";
const quotes = [
  "Small progress is still progress.",
  "Make the next action obvious.",
  "Deep work beats busy work.",
  "One focused session can change a day.",
  "Consistency compounds."
];

const state = JSON.parse(localStorage.getItem(KEY) || "null") || {
  tasks: [], sessions: 0, score: 0, streak: 0, lastDay: null, dark: true
};

let minutes = 25, seconds = 0, running = false, interval = null;

const $ = id => document.getElementById(id);
const save = () => localStorage.setItem(KEY, JSON.stringify(state));

function todayKey(){ return new Date().toISOString().slice(0,10); }
function updateStreak(){
  const today = todayKey();
  if(state.lastDay === today) return;
  if(!state.lastDay){ state.streak = 1; }
  else {
    const a = new Date(state.lastDay), b = new Date(today);
    const diff = Math.round((b-a)/86400000);
    state.streak = diff === 1 ? state.streak + 1 : 1;
  }
  state.lastDay = today; save();
}
function render(){
  updateStreak();
  $("dateText").textContent = new Intl.DateTimeFormat(undefined,{weekday:"long",month:"long",day:"numeric"}).format(new Date());
  $("quote").textContent = quotes[new Date().getDate() % quotes.length];
  $("score").textContent = state.score;
  const done = state.tasks.filter(t=>t.done).length;
  $("taskCount").textContent = `${done}/${state.tasks.length}`;
  $("completed").textContent = done;
  $("sessions").textContent = state.sessions;
  $("streak").textContent = `${state.streak} day${state.streak===1?"":"s"}`;
  $("progressBar").style.width = state.tasks.length ? `${done/state.tasks.length*100}%` : "0%";
  $("taskList").innerHTML = state.tasks.map((t,i)=>`
    <li class="task ${t.done?"done":""}">
      <input type="checkbox" ${t.done?"checked":""} data-i="${i}" aria-label="Complete task">
      <span class="label">${escapeHtml(t.text)}</span>
      <button class="delete" data-del="${i}" aria-label="Delete task">×</button>
    </li>`).join("");
  document.body.classList.toggle("light", !state.dark);
  $("themeBtn").textContent = state.dark ? "☾" : "☀";
}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));}
function drawTimer(){
  $("timer").textContent = `${String(minutes).padStart(2,"0")}:${String(seconds).padStart(2,"0")}`;
  $("timerMode").textContent = `${minutes} min`;
  $("startBtn").textContent = running ? "Pause" : "Start";
}
function setTimer(m){clearInterval(interval);running=false;minutes=m;seconds=0;drawTimer();}
$("taskForm").addEventListener("submit",e=>{
  e.preventDefault(); const text=$("taskInput").value.trim(); if(!text)return;
  state.tasks.push({text,done:false}); $("taskInput").value=""; save(); render();
});
$("taskList").addEventListener("click",e=>{
  const i=e.target.dataset.i, d=e.target.dataset.del;
  if(i!==undefined){state.tasks[i].done=e.target.checked; if(e.target.checked)state.score+=10; save();render();}
  if(d!==undefined){state.tasks.splice(Number(d),1);save();render();}
});
$("themeBtn").onclick=()=>{state.dark=!state.dark;save();render();};
$("clearBtn").onclick=()=>{if(confirm("Reset all local data?")){localStorage.removeItem(KEY);location.reload();}};
$("startBtn").onclick=()=>{
  if(running){clearInterval(interval);running=false;drawTimer();return;}
  running=true;drawTimer();
  interval=setInterval(()=>{
    if(seconds===0){if(minutes===0){clearInterval(interval);running=false;state.sessions++;state.score+=25;save();alert("Focus session complete! +25 points");render();setTimer(25);return;}minutes--;seconds=59;}
    else seconds--;
    drawTimer();
  },1000);
};
$("resetBtn").onclick=()=>setTimer(25);
document.querySelectorAll(".presets button").forEach(b=>b.onclick=()=>setTimer(Number(b.dataset.min)));
render();drawTimer();
