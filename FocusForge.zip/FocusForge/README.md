# FocusForge

A lightweight, responsive productivity dashboard that works entirely in the browser.

## Features

- Task manager with completion tracking
- Focus/Pomodoro timer with 5, 25 and 50 minute presets
- Points, completed-task progress and focus-session statistics
- Daily streak tracking
- Dark/light theme
- Local persistence with `localStorage`
- No backend, dependencies, build step, or account required
- Responsive design for mobile and desktop

## Run locally

Open `index.html` in a browser, or serve the folder with any static web server.

Example:

```bash
python3 -m http.server 8000
```

Then visit `http://localhost:8000`.

## Project structure

```text
focusforge/
├── index.html
├── styles.css
├── app.js
└── README.md
```

## Contributing

Issues and pull requests are welcome. For small improvements, please explain the problem, the proposed change, and how it was tested.

## License

MIT
